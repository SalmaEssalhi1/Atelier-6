class Point{
    private abs : number;
    private ord : number;

    constructor(x :number , y: number){
        this.abs=x;
        this.ord=y;
    }
    public getAbs(): number {
        return this.abs;

    }
    public getOrd(): number {
        return this.ord;
    }
    public setAbs(abs:number){
        this.abs=abs;
    }

    public setOrd(ord: number){
        this.ord=ord;

    }
    public calculerDistance(p: Point): number{
        const x = this.abs-p.getAbs();
        const y = this.ord-p.getOrd();

        return Math.sqrt(Math.pow(x,2)+ Math.pow(y,2)); 
    }
   

}
const point1 = new Point (5,9);
const point2 = new Point (1,4);
 console.log("la distance entre les deuc points est", point1.calculerDistance(point2));