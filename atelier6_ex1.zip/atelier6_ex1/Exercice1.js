"use strict";
class Point {
    constructor(x, y) {
        this.abs = x;
        this.ord = y;
    }
    getAbs() {
        return this.abs;
    }
    getOrd() {
        return this.ord;
    }
    setAbs(abs) {
        this.abs = abs;
    }
    setOrd(ord) {
        this.ord = ord;
    }
    calculerDistance(p) {
        const x = this.abs - p.getAbs();
        const y = this.ord - p.getOrd();
        return Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
    }
}
const point1 = new Point(5, 9);
const point2 = new Point(1, 4);
console.log("la distance entre les deuc points est", point1.calculerDistance(point2));
