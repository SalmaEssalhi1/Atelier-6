import { Personne } from "./Personne";
import { Adresse } from "./Adresse";

export class ListePersonnes{
    private personnes : Personne [];

    constructor(personnes: Personne[]) {
        this.personnes = personnes;
    }

    public getPersonnes(): Personne[] {
        return this.personnes;
    }

    public setPersonnes(personnes: Personne[]): void {
        this.personnes = personnes;
    }

    public findByNom(s: string): Personne | null {
        for (let personne1 of this.personnes) {
            if (personne1.getNom() === s) {
                return personne1;
            }
        }
        return null;
    }
    public findByCodePostal(cp: string): boolean {
        for (let personne1 of this.personnes) {
            for (let a of personne1.getAdresses()) {
                if (a.getCodePostal() === cp) {
                    return true;
                }
            }
        }
        return false;
    }

    public countPersonneVille(ville: string): number {
        let count = 0;
        for (let personne1 of this.personnes) {
            if (personne1.getAdresses().some(a => a.getVille() === ville)) {
                count++;
            }
        }
        return count;
    }
}