"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Personne = void 0;
class Personne {
    constructor(nom, sexe, adresses) {
        this.nom = nom;
        this.sexe = sexe;
        this.adresses = adresses;
    }
    getNom() {
        return this.nom;
    }
    setNom(nom) {
        this.nom = nom;
    }
    getSexe() {
        return this.sexe;
    }
    setSexe(sexe) {
        this.sexe = sexe;
    }
    getAdresses() {
        return this.adresses;
    }
    setAdresses(adresses) {
        this.adresses = adresses;
    }
}
exports.Personne = Personne;
