"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListePersonnes = void 0;
class ListePersonnes {
    constructor(personnes) {
        this.personnes = personnes;
    }
    getPersonnes() {
        return this.personnes;
    }
    setPersonnes(personnes) {
        this.personnes = personnes;
    }
    findByNom(s) {
        for (let personne1 of this.personnes) {
            if (personne1.getNom() === s) {
                return personne1;
            }
        }
        return null;
    }
    findByCodePostal(cp) {
        for (let personne1 of this.personnes) {
            for (let a of personne1.getAdresses()) {
                if (a.getCodePostal() === cp) {
                    return true;
                }
            }
        }
        return false;
    }
    countPersonneVille(ville) {
        let count = 0;
        for (let personne1 of this.personnes) {
            if (personne1.getAdresses().some(a => a.getVille() === ville)) {
                count++;
            }
        }
        return count;
    }
}
exports.ListePersonnes = ListePersonnes;
