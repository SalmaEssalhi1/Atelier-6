import { Adresse } from "./Adresse";

export class Personne{
    private nom: string;
    private sexe: string;
    private adresses: Adresse[];

    constructor(nom: string, sexe: string, adresses: Adresse[]) {
        this.nom = nom;
        this.sexe = sexe;
        this.adresses = adresses;
    }

    public getNom(): string {
        return this.nom;
    }

    public setNom(nom: string): void {
        this.nom = nom;
    }

    public getSexe(): string {
        return this.sexe;
    }

    public setSexe(sexe: string): void {
        this.sexe = sexe;
    }

    public getAdresses(): Adresse[] {
        return this.adresses;
    }

    public setAdresses(adresses: Adresse[]): void {
        this.adresses = adresses;
    }

    
}