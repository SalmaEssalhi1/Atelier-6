"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Adresse_ts_1 = require("./Adresse.ts");
const Personne_ts_1 = require("./Personne.ts");
const ListePersonnes_ts_1 = require("./ListePersonnes.ts");
// Création d'adresses
const adresse1 = new Adresse_ts_1.Adresse("10 rue boukhalef", "Tanger", "3570");
const adresse2 = new Adresse_ts_1.Adresse("25 avenue Hassan II", "Rabat", "5470");
const adresse3 = new Adresse_ts_1.Adresse("3 bd Zerktouni", "Casablanca", "20000");
// Création de personnes avec des adresses
const personne1 = new Personne_ts_1.Personne("Salma", "F", [adresse1]);
const personne2 = new Personne_ts_1.Personne("Youssef", "M", [adresse2]);
const personne3 = new Personne_ts_1.Personne("Sofia", "F", [adresse2, adresse3]);
// Liste de personnes
const liste = new ListePersonnes_ts_1.ListePersonnes([personne1, personne2, personne3]);
// Recherche par nom
console.log("Recherche de 'Youssef':", liste.findByNom("Youssef"));
// Recherche par code postal
console.log("Quelqu’un habite au code postal 5470 ? ", liste.findByCodePostal("5470"));
// Nombre de personnes dans une ville
console.log("Nombre de personnes à Rabat :", liste.countPersonneVille("Rabat"));
