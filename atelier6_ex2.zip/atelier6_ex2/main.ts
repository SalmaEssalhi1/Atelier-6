import { Adresse } from "./Adresse";
import { Personne } from "./Personne";
import { ListePersonnes } from "./ListePersonnes";

// Création d'adresses
const adresse1 = new Adresse("10 rue boukhalef", "Tanger", "3570");
const adresse2 = new Adresse("25 avenue Hassan II", "Rabat", "5470");
const adresse3 = new Adresse("3 bd Zerktouni", "Casablanca", "20000");

// Création de personnes avec des adresses
const personne1 = new Personne("Salma", "F", [adresse1]);
const personne2 = new Personne("Youssef", "M", [adresse2]);
const personne3 = new Personne("Sofia", "F", [adresse2, adresse3]);

// Liste de personnes
const liste = new ListePersonnes([personne1, personne2, personne3]);

// Recherche par nom
console.log("Recherche de 'Youssef':", liste.findByNom("Youssef"));

// Recherche par code postal
console.log("Quelqu’un habite au code postal 5470 ? ", liste.findByCodePostal("5470"));

// Nombre de personnes dans une ville
console.log("Nombre de personnes à Rabat :", liste.countPersonneVille("Rabat"));
