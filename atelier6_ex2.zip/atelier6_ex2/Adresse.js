"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Adresse = void 0;
class Adresse {
    constructor(rue, ville, codePostal) {
        this.rue = rue;
        this.ville = ville;
        this.codePostal = codePostal;
    }
    getRue() {
        return this.rue;
    }
    setRue(rue) {
        this.rue = rue;
    }
    getVille() {
        return this.ville;
    }
    setVille(ville) {
        this.ville = ville;
    }
    getCodePostal() {
        return this.codePostal;
    }
    setCodePostal(codePostal) {
        this.codePostal = codePostal;
    }
}
exports.Adresse = Adresse;
